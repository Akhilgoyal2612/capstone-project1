
<?php 
include('head.php');
include('mysqli_connect.php');
$sql = "SELECT * FROM products";
$result = $dbc->query($sql);
    
?>  

<div class="container">
  <h3>Products</h3>
  

  <div class="row">
  	<?php 
  	if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
  ?>
  	<div class="col-md-4">
        <a href="single.php?p=<?php echo $row['ProductId']; ?>">
  		<img src="image/products/<?php echo $row['image']; ?>" height="150px" width="auto">
  		<div id="name"><?php echo $row['ProductName']; ?></div>
  		<div id="price">$<?php echo $row['Price']; ?></div>
  		<div id="Brand"><?php echo $row['Brand']; ?></div>
        </a>
  	</div>
  	<?php 
}
}
?>
  </div>

  
</div>
<?php 
include('footer.php');
?> 
