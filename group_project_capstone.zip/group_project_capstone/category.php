
<?php 
include('head.php');
include('mysqli_connect.php');
?>  

<div class="container">

    
    <div class="row">
    <?php 
    if(isset($_GET['cat']))
    {
        $cat = $_GET['cat'];
    $sql = "SELECT * FROM products WHERE CategoryId = '$cat' ";
    $result = $dbc->query($sql); 
    if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
   
   
    ?>
    <div class="col-sm-4">
        <a href="single.php?p=<?php echo $row['ProductId']; ?>">
        <div class=""><?php echo $row['ProductName']; ?></div>
        <div class=""><img src="image/products/<?php echo $row['image']; ?>" class="img-responsive" style="width:100%" alt="Image"></div>
        <div class="">$<?php echo $row['Price']; ?></div>
        <div class=""><?php echo $row['Brand']; ?></div>
        </a>
    </div>
    <?php 
         }
    }else
    {
        echo "No result Found";
    }
    }
    ?>
</div>
    

<?php 
include('footer.php');
?> 
