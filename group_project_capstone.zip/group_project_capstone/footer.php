<footer>
  <p>copyright &copy; 2020</p>
  <p><a href="">info@techshop.com</a></p>
</footer>
</body>
</html>