
<?php 
include('head.php');
include('mysqli_connect.php');

    
?>  

<div class="container">
  <h3>Single Product</h3>
  

  <div class="row">
  	<?php 
    if(isset($_GET['p']))
    {
        $p = $_GET['p'];
        $sql = "SELECT * FROM products WHERE ProductId = '$p' ";
        $result = $dbc->query($sql);
        if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
   
  	
  ?>
  	<div class="col-md-4">
        <a href="single.php">
  		<img src="image/products/<?php echo $row['image']; ?>" height="150px" width="auto">
  		<div id="name"><?php echo $row['ProductName']; ?></div>
  		<div id="price">$<?php echo $row['Price']; ?></div>
        <div id="Brand"><?php echo $row['Brand']; ?></div>
  		<div id="Description"><?php echo $row['Description']; ?></div>
        </a>
  	</div>
  	<?php 
         }
}
}
?>
  </div>

  
</div>
<?php 
include('footer.php');
?> 
