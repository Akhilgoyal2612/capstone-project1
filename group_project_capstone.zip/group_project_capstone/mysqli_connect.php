<?php
$dbc = new mysqli("localhost","root","","mobiledb");

// Check connection
if ($dbc -> connect_errno) {
  echo "Failed to connect to MySQL: " . $dbc -> connect_error;
  exit();
}
else
{
	//echo "success";
}
?>
