
<?php 
include('head.php');
include('mysqli_connect.php');
?>  

<div class="container">
  <div class="jumbotron" id="banner">
      <div class="container text-center">
        <h1>Tech Shop</h1>      
        <p>One Store For All Tech Need</p>
      </div>
</div>
    
    <div class="row">
    <?php 
    $sql = "SELECT * FROM category LIMIT 3";
    $result = $dbc->query($sql); 
    if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
    ?>
    <div class="col-sm-4">
      <div class="panel panel-primary">
        <div class="panel-heading"><?php echo $row['CategoryName']; ?></div>
        <div class="panel-body"><img src="image/category/<?php echo $row['CategoryImg']; ?>" class="img-responsive" style="width:100%" alt="Image"></div>
        <div class="panel-footer"><a href="category.php?cat=<?php echo $row['CategoryId']; ?>">Explore</a></div>
      </div>
    </div>
    <?php 
    }
    }
    ?>
</div>
    
<div class="row">
    <h1>Section 3</h1>
</div>
<?php 
include('footer.php');
?> 
